#include<iostream>
using namespace std;
class MyClass{
    public:
    string txt1;
    string txt2;
    MyClass();
    ~MyClass();
    void fonction1(){
        cout<<"choix de texte"<<endl;
        cin>>txt1;
        cout<<"le texte est:"<<txt1<<endl;

    }
    void fonction2(){
        cout<<"choix de texte:"<<endl;
        cin>>txt2;
        cout<<"le texte est :"<<txt2<<endl;
    }
};
MyClass ::MyClass(){
    cout<<"const par defaut"<<endl;

}
MyClass ::~MyClass(){
    cout<<"end of"<<endl;
}
int main(){
    MyClass c1;
    c1.fonction1();
    return 0 ;
}

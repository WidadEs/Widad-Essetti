#include<iostream>
using namespace std;
class Shape {
    private :
    int largeur;
    int hauteur;
    public:
    Shape(){
        cout<<"je suis le constructeur par défaut"<<endl;
    }
  
    Shape(int l,int h){
        this->largeur= l;
        this->hauteur= h;

    }};
    class triangle : public Shape{
    public:
     void area(int l,int h){
     int resultat1;
     resultat1 = (l+h)/2 ;
     cout<<"le resultat est:"<<resultat1<<endl;
     }
    };
    class rectangle : public Shape{
        public :
        void area(int l,int h){
        int resultat;
        resultat = (l*h) ;
        cout<<"le resultat est:"<<resultat<<endl;
        }
   };
    int main(){
        triangle tr1;
        rectangle rec1;
        tr1.area(5,20);
        rec1.area(5,20);
        return 0;
    }

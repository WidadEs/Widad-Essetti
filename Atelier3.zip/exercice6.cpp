#include<iostream>
using namespace std;
class Personne{
    private:
    string nom;
    string prenom;
    int date;
    public:
    Personne(){
        cout<<"constructeur par defaut"<<endl;
    }
    Personne(string nom,int date){
        this->nom=nom;
        this->date=date;
    }
    void afficher(string prenom,string nom,int date){
        this->date=date;
        this->nom=nom;
        this->prenom=prenom;
        cout<<"le nom est"<<nom<<endl;
        cout<<"le prenom est"<<prenom<<endl;
        cout<<"la date de naissance est:"<<date<<endl;
    }
};
class Employee : public Personne{
    public:
    string nom;
    string prenom;
    int date;
    int salaire;
    Employee(){
        cout<<"const par defaut"<<endl;
    }
    void afficher(string prenom,string nom,int date ,int salaire){
        this->date=date;
        this->nom=nom;
        this->prenom=prenom;
        this->salaire=salaire;
        cout<<"le nom est"<<nom<<endl;
        cout<<"le prenom est"<<prenom<<endl;
        cout<<"la date de naissance est:"<<date<<endl;
        cout<<"le salaire est:"<<salaire<<endl;
}
};
class Chef : public Employee{
    public :
    string nom;
    string prenom;
    int date;
    int salaire;
    string service;
    Chef(){
        cout<<"const par defaut"<<endl;
    }

void afficher(string prenom,string nom,int date, int salaire){
        this->date=date;
        this->nom=nom;
        this->prenom=prenom;
        this->salaire=salaire;
        this->service=service;
        cout<<"le nom est"<<nom<<endl;
        cout<<"le prenom est"<<prenom<<endl;
        cout<<"la date de naissance est:"<<date<<endl;
        cout<<"le salaire est:"<<salaire<<endl;
        cout<<"le service est:"<<service<<endl;
}};
class Directeur : public Chef
{
    public:
    
    string nom;
    string prenom;
    int date;
    int salaire;
    string service;
    string societeacompagne;
    Directeur(){
        cout<<"const par defaut"<<endl;
    }

void afficher(string prenom,string nom,int date ,int salaire){
        this->date=date;
        this->nom=nom;
        this->prenom=prenom;
        this->salaire=salaire;
        this->service=service;
        this->societeacompagne=societeacompagne;
        cout<<"le nom est"<<nom<<endl;
        cout<<"le prenom est"<<prenom<<endl;
        cout<<"la date de naissance est:"<<date<<endl;
        cout<<"le salaire est:"<<salaire<<endl;
        cout<<"le service est:"<<service<<endl;
        cout<<"societe acompagne est:"<<societeacompagne<<endl;
}};

#include<iostream>
using namespace std;
class mere
{
 
 public:
   void display(){
   cout<<"je suis la classe mère"<<endl;
}

};
class fille : public mere {
   
    public:
    void display(){
    cout<<"je suis la classe fille"<<endl;
    }
};
int main(){
    fille f1;
    f1.display();
    return 0;
}
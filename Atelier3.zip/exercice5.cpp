#include<iostream>
using namespace std;
class Animal{
    public:
    string nom;
    int age;
   void set_value(){
    cout<<"je suis:"<<nom<<endl;
    cout<<"j'ai:"<<age<<endl;
   }
};
class Zebra:public Animal{
    public:
    string lieuorigine;
    void set_value(string nom,int age ,string lieuorigine){
        this->nom=nom;
        this->age=age;
        this->lieuorigine=lieuorigine;
    cout<<"le nom est:"<<nom<<endl;
    cout<<"l'age est:"<<age<<endl;
    cout<<"lieu d'origine est:"<<lieuorigine<<endl;
    }
};

class Dolphin:public Animal{
    public:
    string lieuorigine;
    void set_value(string nom,int age ,string lieuorigine){
        this->nom=nom;
        this->age=age;
        this->lieuorigine=lieuorigine;
    cout<<"le nom est:"<<nom<<endl;
    cout<<"l'age est:"<<age<<endl;
    cout<<"lieu d'origine est:"<<lieuorigine<<endl;
    }};


int main(){
    Zebra Z1;
    Dolphin D1;
    Z1.set_value("zebra",5,"Afrique centrale");
    D1.set_value("dolphin",4,"australe");
   

    return 0;
}
